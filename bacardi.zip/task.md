Done
######
Las fuentes
Se cortan las palabras hacia abajo en Iphone 8
Los botones del formulario salen inclinados a la derecha
En la ruleta que el murciélago de en medio que no gire
Un efecto de sombra en el medio de la ruleta para que quede lo mas parecido al diseño
######

Done
######
Current
Agregar ícono para abrir el botón de dónde se muestra la etiqueta de la botella
Iphone 8, Iphone 7 plus, LG revisar la ruleta
######