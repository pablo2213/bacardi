/*import { useState, useEffect } from 'react'
import StepHeader from './StepHeader'
import StepTitle from './StepTitle'*/
import snowboard_center_image from '../../images/snowboard-center.png'
/*import StepRewardBody from './StepRewardBody'*/
/*import StepRewardButtonFooter from './StepRewardButtonFooter'*/

export default function StepDraw() {
	return (
		<div className="draw-container">
			<img src={snowboard_center_image} alt="" className="img-fluid draw-img" />
		</div>
	)
}