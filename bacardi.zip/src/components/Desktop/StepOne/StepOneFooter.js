export default function SteoOneFooter() {
	return (
		<div className="stepone-container">
			<p className="stepone-footer">#MENORESNIUNAGOTA</p>
		</div>
	)
}