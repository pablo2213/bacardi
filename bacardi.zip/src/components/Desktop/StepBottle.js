import bottle from '../../images/bg-bottles-bottom.png'

export default function StepBottle() {
	return (
		<div id="stepBottle" className="stepone-container">
			<img src={bottle} alt="" className="img-fluid bottle-bottom" />
		</div>
	)
}