
export default function Loader({ id }) {
	return (<span id={id} className="loader"></span>)
}