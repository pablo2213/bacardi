
export default function StepTwoBody() {
	return (
		<div className="steptwo-container">
			<div className="steptwo-content">
				<h4 className="fw-bold text-center m-0">Ingresa los datos de tu botella Bacardí Carta Oro o Añejo</h4>
				<p className="text-center">y participa en el sorteo de un fin de semana con tus mejores amigos en la nieve.</p>
			</div>
		</div>
	)
}