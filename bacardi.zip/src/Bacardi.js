import './Bacardi.css';
import Main from './components/Main'

function Bacardi() {
  return (
    <section className="Bacardi">
      <Main />
    </section>
  );
}

export default Bacardi;
